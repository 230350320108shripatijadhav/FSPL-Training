package Ten.March.task1.Restaurant;

public class Restaurant {

	String[] menuItem;
	double[] prices;
	double[] ratings;
	
	int itemCount;
	
	public Restaurant(int maxItems) {
		// TODO Auto-generated constructor stub
		this.menuItem=new String[maxItems];
		this.prices= new double[maxItems];
		this.ratings=new double[maxItems];
		this.itemCount=0;
	}
	public void addItem(String item,double price, double rating) {
		if (itemCount<menuItem.length) {
			menuItem[itemCount]=item;
			prices[itemCount]=price;
			ratings[itemCount]=rating;
			itemCount++;
			
			
		}else {
			System.out.println("can not add more items , menu is full ");
		}
	}
	public void removeItem(String item) {
		int index=-1;
		for (int i = 0; i < itemCount; i++) {
			if (menuItem[i].equalsIgnoreCase(item)) {
				index=i;
				break;
			}
		}
		if (index!=-1) {
			for (int i = index; i < itemCount-1; i++) {
				menuItem[i]=menuItem[i+1];
				prices[i]=prices[i+1];
				ratings[i]=ratings[i+1];
			}
			itemCount--;
		} else {
            System.out.println("item is not found ");
		}
		
	}
	public double calAvgRating() {
		if(itemCount==0) return 0.0;
		double sum=0;
		for (int i = 0; i < itemCount; i++) {
			sum+=ratings[i];
		}
		return sum/itemCount;
	}
	
	public void displayMenu() {
		System.out.println("All Menu ");
		for (int i = 0; i < itemCount; i++) {
			System.out.println(menuItem[i]+ "  price - "+prices[i]+" ratings "+ratings[i]);
		}
	}
}
