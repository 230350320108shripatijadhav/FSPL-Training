package Ten.March.task1.Restaurant;

public class Main {
	public static void main(String[] args) {
		
		Restaurant restaurant= new Restaurant(3);
		
		restaurant.addItem("Vada paw ", 15.00, 4.6);
		restaurant.addItem("chapati ", 12.00, 4.9);
		restaurant.addItem("paneer", 90.00, 5.00);
	
		restaurant.displayMenu();
		
		System.out.println(" avg rating  "+restaurant.calAvgRating());
		
		restaurant.removeItem("chapati ");
		restaurant.displayMenu();
	}

}
