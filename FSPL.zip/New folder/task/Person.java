package Ten.March.task;

public class Person {

	String name;
	int age;

	public Person(String a, int b) {
		// TODO Auto-generated constructor stub
		name = a;
		age = b;
	}
 
	public String toString() {
		return "naMe "+ name +" age " + age;
	}

	public static void main(String[] args) {
		Person p = new Person("Vivek", 26);
		Person p1 = new Person("niki", 21);
		System.out.println(p);
		System.out.println(p1);
		
	}

}
