package Ten.March.task;

public class Dog {

	String name;
	String breed;

	public Dog(String a, String b) {
		name = a;
		breed = b;

	}
	public void setNaMe(String a) {
		name=a;
	}
	public void setBreed(String b) {
		breed=b;
	}
	public String toString() {
		return "name "+name +"breed "+breed;
	}
	public static void main(String[] args) {
		Dog dog=new Dog("Moti", "lab");
		Dog d1=new Dog("sagya", "pitapuri");
		System.out.println(dog);
		System.out.println(d1);
		
		//modify
		dog.setNaMe("wagya");
		dog.setBreed("bulldog");
		
		d1.setNaMe("jimmy");
		d1.setBreed("german");
		
		System.out.println(dog);
		System.out.println(d1);
	}
}
