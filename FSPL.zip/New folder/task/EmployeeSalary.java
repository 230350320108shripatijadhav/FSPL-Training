package Ten.March.task;

public class EmployeeSalary {
	
	 String name;
     String jobTitle;
      double salary;

    
    public EmployeeSalary(String a, String b, double c) {
        name = a;
        jobTitle = b;
        salary = c;
    }
    public void printEmp() {
        System.out.println("employee " + name);
		System.out.println("jobe " + jobTitle);
		System.out.println("salary " + salary);
	}

	public double calIncrement(double percentage) {
		return salary * (percentage / 100);
    }
    
    public void updateSalary(double percentage) {
        double increment = calIncrement(percentage);
        salary = salary+increment;
        System.out.println("uodate salary " + salary);
    }
    public static void main(String[] args) {
		EmployeeSalary e=new EmployeeSalary("Sham", "java Dev", 14000);
		e.printEmp();
		
		e.updateSalary(10);
	}
}
