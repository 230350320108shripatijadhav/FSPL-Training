package Ten.March.task;

public class Rectangle {
	double width;
	double height;

	public Rectangle(double a, double b) {
		width = a;
		height = b;
	}

	public double calArea() {
		return width * height;
	}
	
	public double calParameter() {
		return 2*(width+height);
	}
	public static void main(String[] args) {
		Rectangle r=new Rectangle(5.0, 10.0);
		System.out.println("Area "+r.calArea());
		System.out.println("calParameter "+r.calParameter());
	}

}
