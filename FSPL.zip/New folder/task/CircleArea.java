package Ten.March.task;

public class CircleArea {

	double radius;
	
	public CircleArea(double r) {
		radius=r;
	}
	
	public void setRadious(double r) {
		radius =r;
	}
	public double getRadious() {
		return radius;
	}
	
	public double calArea() {
		return Math.PI*radius*radius;
	}
	
	public double calCircumference() {
		return 2*Math.PI*radius;
	}
	
	public static void main(String[] args) {
		
		CircleArea c=new CircleArea(7.0);
	
		System.out.println("area "+c.calArea());
		System.out.println("calCircumference "+c.calCircumference());
		
		c.setRadious(8.0);
		System.out.println("area "+c.calArea());
		System.out.println("calCircumference "+c.calCircumference());
		
	}
}
