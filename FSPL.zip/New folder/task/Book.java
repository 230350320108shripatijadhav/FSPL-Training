package Ten.March.task;

public class Book {

	String title;
	String author;
	String isbn;

	public Book(String t, String a, String i) {
		title = t;
		author = a;
		isbn = i;
	}

	public String toString() {
		return "title: " + title + ", author: " + author + ", isbn: " + isbn;
	}

	public void print() {
		System.out.println(toString());
	}

	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public String getIsbn() {
		return isbn;
	}
}

