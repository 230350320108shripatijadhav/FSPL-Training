package Ten.March.task;

import java.util.ArrayList;

class Library {
    private Book[] books;
    private int count;

    public Library(int capacity) {
        books = new Book[capacity]; 
        count = 0;
    }

    public void addBook(String title, String author, String isbn) {
        if (count < books.length) {
            books[count++] = new Book(title, author, isbn);
            System.out.println("book added: " + title);
        } else {
            System.out.println("library full");
        }
    }

    public void removeBook(String isbn) {
        for (int i = 0; i < count; i++) {
            if (books[i].getIsbn().equals(isbn)) {
                System.out.println("book remove: " + books[i]);
             
                for (int j = i; j < count - 1; j++) {
                    books[j] = books[j + 1];
                }
                books[count - 1] = null; 
                count--;
                return;
            }
        }
        System.out.println("Book with isbn " + isbn + " not found.");
    }

    public void printAllBooks() {
        System.out.println("\nBOOK collection:");
        if (count == 0) {
            System.out.println("book is not available");
        } else {
            for (int i = 0; i < count; i++) {
                books[i].print();
            }
        }
    }
    class Book {
        private String title;
        private String author;
        private String isbn;

        public Book(String a, String b, String c) {
            title = a;
            author = b;
            isbn = c;
        }

        public String getIsbn() {
            return isbn;
        }

        public void print() {
            System.out.println("title " + title + ", author " + author + ", isbn " + isbn);
        }
    }

    public static void main(String[] args) {
        Library library = new Library(5); 

        library.addBook("Jangal Story", "K K Kkm", "123");
        library.addBook("Forest Story", "A B ABC", "321");

        library.printAllBooks();

        library.removeBook("123");

        library.printAllBooks();
    }
}