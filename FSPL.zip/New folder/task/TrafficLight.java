package Ten.March.task;

public class TrafficLight {

	String color;
	int duration;

	public TrafficLight(String a, int b) {

		color = a;
		duration = b;
	}

	public void changeColor(String newColor, int newDuration) {

		System.out.println(" light changed " + color + " for " + duration + " sec");
	}

	public boolean isRed() {
		return color.equalsIgnoreCase("red");
	}

	public boolean isGreen() {
		return color.equalsIgnoreCase("green");
	}

	public static void main(String[] args) {
		TrafficLight t=new TrafficLight("red", 60);
		 System.out.println("is light red " + t.isRed());
		 System.out.println("is light red " + t.isGreen());
		 
		 t.changeColor("Green", 45);
		 System.out.println("is light red " + t.isRed());
		 System.out.println("is light red " + t.isGreen());
		
		 

	}
}
