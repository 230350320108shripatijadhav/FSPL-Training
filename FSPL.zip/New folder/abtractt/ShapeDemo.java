package Ten.March.task1.abtractt;

public class ShapeDemo {
	
	public static void main(String[] args) {
		
		Shape circule= new Circle(5);
		System.out.println("circle ");
		circule.display();
		
		Shape triangle = new Triangle(12, 23, 43);
		System.out.println("triangle ");
		triangle.display();
		
		Shape rectangle= new Rectangle(5,3);
		
		System.out.println("Rectangle ");
		rectangle.display();
	}

}
