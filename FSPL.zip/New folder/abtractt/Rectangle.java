package Ten.March.task1.abtractt;

public class Rectangle extends Shape {

	double length;
	double width;

	public Rectangle(double a, double b) {
		// TODO Auto-generated constructor stub
		length = a;
		width = b;
	}

	@Override
	double calculateArea() {
		// TODO Auto-generated method stub
		return length * width;
	}

	@Override
	double calculatePerimeter() {
		// TODO Auto-generated method stub
		return 2 * (length + width);
	}

}
