package Ten.March.task1.abtractt;

public class Triangle  extends Shape{
	
	double sideA;
	double sideB;
	double sideC;
	
public Triangle(double a, double b,double c) {
	// TODO Auto-generated constructor stub
	sideA=a;
	sideB=c;
	sideC=c;
}
	@Override
	double calculateArea() {
		// TODO Auto-generated method stub
		double s=(sideA+sideB+sideC)/2;
		return Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));
	
	}

	@Override
	double calculatePerimeter() {
		// TODO Auto-generated method stub
		return sideA+sideB+sideC ;
		}

}
