package Ten.March.task1.abtractt;
abstract class Shape {

	abstract double calculateArea();
	abstract double calculatePerimeter();
	
	public void display() {
		System.out.println("Area " +calculateArea());
		System.out.println("Perimeter " +calculatePerimeter());
	}
}
