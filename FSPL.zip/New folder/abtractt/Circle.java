package Ten.March.task1.abtractt;

public class Circle extends Shape {

	double radius;
	static final double PI=3.14;
	
	public Circle(double a) {
		// TODO Auto-generated constructor stub
	
	radius=a;}
	
	@Override
	double calculateArea() {
		// TODO Auto-generated method stub
		return PI*radius *radius;
	}

	@Override
	double calculatePerimeter() {
		// TODO Auto-generated method stub
		return 2*radius*PI;
	}

}
