package Ten.March.task1;

public class Schoole {

	FlyStudent[] students;
	FlyTeacher[] teachers;

	SchoolClass[] classes;

	int studentCount, teacherCount, classCount;

	public Schoole(int maxStudents, int maxTeachers, int maxClasses) {
		// TODO Auto-generated constructor stub
		students = new FlyStudent[maxStudents];
		teachers = new FlyTeacher[maxTeachers];
		classes = new SchoolClass[maxClasses];
		studentCount = 0;
		teacherCount = 0;
		classCount = 0;
	}

	public void addStudent(String name, int id) {
		if (studentCount < students.length) {
			students[studentCount++] = new FlyStudent(name, id);

		} else {
			System.out.println("student capacity reached ");
		}
	}

	public void removeStudent(int id) {
		for (int i = 0; i < studentCount; i++) {
			if (students[i].id == id) {
students[i] =students[studentCount-1];
students[studentCount-1]=null;
studentCount--;
return;
			} 
		}
		System.out.println("Student not found ");
	}
	
	public void printStudent() {
		System.out.println("all students list ");
		for (int i = 0; i < studentCount; i++) {
			System.out.println(students[i]);
		}
	}
	public void addTeacher(String name, String subject) {
		if (teacherCount< teachers.length) {
			teachers[teacherCount++]=new FlyTeacher(name, subject);
			
		}else {
			System.out.println("Teacher capacity reached ");
		}
	}
	public void removeTeacher(String name) {
		for (int i = 0; i < teacherCount; i++) {
			if (teachers[i].name==name) {
				teachers[i]=teachers[teacherCount-1];
				teachers[teacherCount-1]=null;
				teacherCount--;
				return;
			}
		}
		System.out.println("teacher not found ");
	}
	public void printTeachers() {
		System.out.println("all teachers ");
		for (int i = 0; i < teacherCount; i++) {
			System.out.println(teachers[i]);
			
		}
	}
	
	public void createClass(String className, String teacherName, int maxStudents) {
		for (int i = 0; i < teacherCount; i++) {
			if (teachers[i].name.equalsIgnoreCase(teacherName)) {
				if (classCount <classes.length) {
					classes[classCount++]=new SchoolClass(className, teachers[i], maxStudents);
				} else {
					System.out.println("class capacity reached");

				}
				return;
			} 
		}
		System.out.println("Teacher not found ");
	}

	public void printClass() {
		for (int i = 0; i < classCount; i++) {
			//System.out.println(classes[i]);
		classes[i].printClassDetails();
		}
	}
}
