package Ten.March.task1;

public class Song {

	String title;
	String artist;
	
	public Song(String a,String b) {
		// TODO Auto-generated constructor stub
	title=a;
	artist=b;
	}
	public String  getTitle() {
		return title;
	}
	
	public String getArtist() {
		return artist;		
	}
	
	public String toString() {
		return "title  "+title+"  artist "+artist;
	}
}
