package Ten.March.task1;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Airplane {

	String flightNumber;
	String destination;
	LocalTime departureTime;
	LocalTime actualDepartureTime;

	public Airplane(String fNumber, String dest, String depTime) {
		flightNumber = fNumber;
		destination = dest;
		departureTime = LocalTime.parse(depTime, DateTimeFormatter.ofPattern("HH:mm"));
		actualDepartureTime = departureTime;
	}
	
	public void checkFlightStatus() {
		if (actualDepartureTime.equals(departureTime)) {
			System.out.println("flightNumber "+flightNumber+" to "+destination);
			
		} else {
			System.out.println("flightNumber "+flightNumber+" to "+destination+" is delay by "+calculateDelay()+" minutes");

		}
	}
	 public void setDelay(int minutes) {
		 actualDepartureTime=departureTime.plusMinutes(minutes);
		 System.out.println("flightNumber "+flightNumber+" destination  "+destination+" is delayed by " + minutes + "minute");
	 }
	public long calculateDelay() {
		return java.time.Duration.between(departureTime, actualDepartureTime).toMinutes();
		
	}
	
	public void displayFlightDetails() {
		System.out.println("flightNumber "+ flightNumber+" destination "+destination
				            +" departureTime "+departureTime+" actualDepartureTime "+actualDepartureTime );
	}
	public static void main(String[] args) {
		Airplane a=new Airplane("ABCD", "pune", "15:45");
		a.displayFlightDetails();
		a.checkFlightStatus();
		a.setDelay(30);
		a.checkFlightStatus();
	}
	
}
