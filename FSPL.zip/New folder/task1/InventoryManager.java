package Ten.March.task1;

import java.util.Scanner;

public class InventoryManager {
	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Inventory inventory=new Inventory(5);
		
		  inventory.addProduct("Laptop", 5, 2);
	        inventory.addProduct("Mouse", 10, 5);
	        inventory.addProduct("Keyboard", 3, 1);
	        inventory.displayInventory();
	        inventory.checkLowInventory();
	        
	        System.out.println("enter product removing ");
	        String productName=s.nextLine();
	        inventory.removeProduct(productName);
	        
	        System.out.println("new updated ");
	        inventory.displayInventory();

	        inventory.checkLowInventory();
	}

}
