package Ten.March.task1;

public class SchoolClass {
	String className;
	FlyTeacher teacher;
	FlyStudent[] students;
	int studentCount;
	
	public SchoolClass(String a, FlyTeacher b,int c) {
		// TODO Auto-generated constructor stub
		className=a;
		teacher=b;
		students=new FlyStudent[c];
		studentCount=0;
	}
	public void addStudent(FlyStudent flyStudent) {
		if(studentCount<students.length) {
			students[studentCount++]=flyStudent;
		}else {
			System.out.println("Student is full ");
		}
	}
	
	public void printClassDetails() {
		System.out.println("class name "+className);
		System.out.println("teachers "+ teacher.name);
		System.out.println("students");
		for (int i = 0; i < studentCount; i++) {
			System.out.println(" "+students[i]);
		}
		
	}

	
}
