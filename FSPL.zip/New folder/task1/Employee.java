package Ten.March.task1;

import java.time.LocalDate;
import java.time.Period;

public class Employee {
	
	String name;
	double salary;
	LocalDate hireDate;

	public Employee(String a, double b, int year,int month,int day) {
	name=a;
	salary=b;
	hireDate=LocalDate.of(year, month, day);
		
	}
	public int getYearsOfService() {
		return  Period.between(hireDate, LocalDate.now()).getYears();
	}
	public void displayEmp() {
		System.out.println("name "+name+" salary "+salary+" hireDate "+hireDate+" year work "+ getYearsOfService());
	}
	public static void main(String[] args) {
		Employee e=new Employee("Sham", 50000, 2022, 6, 15);
	e.displayEmp();
	}
}
