package Ten.March.task1;

public class Product {
	
	
	String name;
	int quantity;
	int threshold;
	
	public Product(String a, int b,int c) {
		// TODO Auto-generated constructor stub
		name=a;
		quantity =b;
		threshold=c;
	}
	
	public boolean isLowStock() {
		return 	quantity<= threshold;
	}
	

}
