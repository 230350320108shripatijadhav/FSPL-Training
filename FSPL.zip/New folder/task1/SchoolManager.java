package Ten.March.task1;

public class SchoolManager {
	
	public static void main(String[] args) {
		Schoole s= new Schoole(10,5,5);
		
		s.addTeacher("niki ", "math");
		s.addTeacher("sham "," sci");
		s.printTeachers();
		
		s.addStudent("ram", 123);
		s.addStudent("AAA", 253);
		s.printStudent();
		s.createClass("Math 101", "niki ", 5);
		
		s.printStudent();
		s.printTeachers();
		s.printClass();
	}

}
