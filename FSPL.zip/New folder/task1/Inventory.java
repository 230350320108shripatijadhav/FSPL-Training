package Ten.March.task1;

public class Inventory {
	
	
	Product[] products;
	int count;
	
	public Inventory (int size){
		products =new Product[size];
		count=0;
		
		
	}
	public void addProduct(String name,int quantity,int threshold) {
		if (count<products.length) {
			products[count++]=new Product(name, quantity, threshold);
		} else {
			System.out.println("inventory is full");
		}
	}
	public void removeProduct(String name) {
		for (int i = 0; i < count; i++) {
			//if (products[i].name.equalsIgnoreCase(name)) {
		  if (products[i].name.equalsIgnoreCase(name)) {
				products[i]=products[count-1];
				products[count-1]=null;
				count--;
				System.out.println("product "+name+" removed");
			} }
System.out.println(" product not found");
			
		
	}
	public void displayInventory() {
	    System.out.println("current inventory:");
	    for (int i = 0; i < count; i++) {
	        System.out.println("- " + products[i].name + " (Stock: " + products[i].quantity + ")");
	    }
	}

	 public void checkLowInventory() {
		 System.out.println("low inventory products ");
		 for (int i = 0; i < count; i++) {
			 if (products[i].isLowStock()) {
	                System.out.println( products[i].name + " Stock: " + products[i].quantity );
	            }
		}
		 
	 }

}
