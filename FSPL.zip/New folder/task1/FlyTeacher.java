package Ten.March.task1;

public class FlyTeacher {
	String name;
	String subject;

	public FlyTeacher(String a, String b) {
		// TODO Auto-generated constructor stub
		name = a;
		subject = b;
	}

	public String toString() {
		return "TEacheName "+name+ " subject"+ subject;
	}
	
	

}
