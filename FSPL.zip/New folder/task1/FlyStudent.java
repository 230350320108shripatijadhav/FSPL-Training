package Ten.March.task1;

public class FlyStudent {

	String name;
	int id;

	public FlyStudent(String a, int b) {
		// TODO Auto-generated constructor stub
		name = a;
		id = b;
	}
	
	public String toString() {
		return "stu id " + id + " name ";
	}

}
