package Ten.March.task1;

import java.util.Random;

public class MusicLibrary {
	
	Song[] songs;
	int songCount;
	Random random;
	
	public MusicLibrary(int capacity) {
		// TODO Auto-generated constructor stub
		songs=new Song[capacity];
		songCount=0;
		random=new Random();
		
	}
	public void addSong(String title, String artist ) {
		if (songCount<songs.length) {
			songs[songCount++]=new Song(title, artist);
			System.out.println("");
		} else {
			  System.out.println("library is full  ");
		}
	}
	public void removeSong(String title) {
		for (int i = 0; i < songCount; i++) {
			if (songs[i].getTitle().contentEquals(title)) {
				songs[i]=songs[songCount-1];
				songs[songCount-1]=null;
				songCount--;
				System.out.println("removed  "+title);
				return;
			}
		}
		System.out.println("song not found "+title);
	}
	
	public void playRandomSong() {
		if (songCount==0) {
			System.out.println("no song in libray  ");
		} else {
			Song randomSong=songs[random.nextInt(songCount)];
			System.out.println("now playing "+randomSong);

		}
	}
	public void displaySong() {
		if (songCount==0) {
			System.out.println("no song in library");
		} else {
for (int i = 0; i < songCount; i++) {
	System.out.println(songs[i]);
}
		}
	}

}
