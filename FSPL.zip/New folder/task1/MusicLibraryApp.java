package Ten.March.task1;

public class MusicLibraryApp {
	public static void main(String[] args) {
		
		MusicLibrary library=new MusicLibrary(5);
		 library.addSong("pankha hote to ", " nitin");
	        library.addSong("lag ja gale ", "  niki");
	        library.addSong("phool tume bheja ", " shree");

	        System.out.println();
	        library.displaySong();
	        
	        System.out.println();
	        library.playRandomSong();
	        
	        
	        System.out.println();
	        library.removeSong("phool tume bheja ");
	        library.displaySong();

	}

}
