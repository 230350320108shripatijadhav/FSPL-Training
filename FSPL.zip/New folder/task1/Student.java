package Ten.March.task1;

import java.util.ArrayList;

public class Student {

    String name;
    String grade;
    ArrayList<String> courses;

    public Student(String name, String grade) {
        this.name = name;
        this.grade = grade;
        this.courses = new ArrayList<>();
    }

    public void addCourse(String course) {
        if (!courses.contains(course)) {
            courses.add(course);
            System.out.println(course + " added ");
        } else {
            System.out.println(course + " already exists");
        }
    }

    public void removeCourse(String course) {
        if (courses.contains(course)) {
            courses.remove(course);
            System.out.println(course + " removed");
        } else {
            System.out.println(course + " not in list");
        }
    }

    public void displayStudent() {
        System.out.println("name " + name + ", grade " + grade + ", courses " + courses);
    }

    public static void main(String[] args) {
        Student s = new Student("Vivek", "A++");
        s.addCourse("Physics");
        s.addCourse("Math");
        s.addCourse("Marathi");
        s.addCourse("Eng");
        s.removeCourse("Physics");
        s.displayStudent();
    }
}
