package Ten.March.task1.Movie;

import java.util.Arrays;

public class Movie {
	String title;
	String director;
	String[] actors;
	String[] reviews;
	int actorCount;
	int reviewCount;

	
	public Movie(String title, String director, int maxActors, int maxReviews) {
		// TODO Auto-generated constructor stub
		this.title = title;
        this.director = director;
        this.actors = new String[maxActors];
        this.reviews = new String[maxReviews];
        this.actorCount = 0;
        this.reviewCount = 0;
		
	}
	public void addActor(String actor) {
		if (actorCount<actors.length) {
			actors[actorCount++]=actor;
			
			
		}
		else {
			System.out.println("can not add more actores");
		}
	}
	public void addReview(String review) {
		if (reviewCount<reviews.length) {
			reviews[reviewCount++]=review;
			
		} else {
System.out.println("can not add more review");
		}
	}
	 public void displayMovieInfo() {
		 System.out.println("title "+title);
		 System.out.println("director"+ director);
		  System.out.println("Actors: " + Arrays.toString(Arrays.copyOf(actors, actorCount)));
	        System.out.println("Reviews: " + Arrays.toString(Arrays.copyOf(reviews, reviewCount)));
	    }
	 public static void main(String[] args) {
		 
		 Movie movie=new Movie("dhole", " sham kam ", 5, 6);
		 
		 movie.addActor("sham rao");
		 movie.addActor("anil pawar");
		 movie.addActor("kkk mmm");
		 
		 movie.addReview("good movies");
		 movie.addReview("moder cinema");
		 
		 movie.displayMovieInfo();
	}
}
